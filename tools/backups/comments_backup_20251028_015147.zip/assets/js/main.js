(() => {
  const $ = (s, r = document) => r.querySelector(s);

  function ready(fn) {
    document.readyState !== "loading"
      ? fn()
      : document.addEventListener("DOMContentLoaded", fn);
  }

  function placePanel() {
    const h = document.querySelector(".tgx-scope .tgx-header");
    const y = h ? h.getBoundingClientRect().bottom + window.scrollY : 110;
    document.documentElement.style.setProperty("--tgx-header-bottom", `${y}px`);
  }

  async function includePart(selector, url) {
    const host = $(selector);
    if (!host) return false;
    try {
      const res = await fetch(url, { cache: "no-store" });
      if (!res.ok) return false;
      host.innerHTML = await res.text();
      return true;
    } catch {
      return false;
    }
  }

  function bindMenu() {
    const toggle = $("#allpagesToggle");
    const panel = $("#mega-allpages");
    if (!toggle || !panel) return;

    if (toggle.dataset.bound === "1") return;
    toggle.dataset.bound = "1";

    function openPanel(yes) {
      panel.classList.toggle("is-open", !!yes);
      toggle.classList.toggle("is-current", !!yes);
      toggle.setAttribute("aria-expanded", String(!!yes));
    }

    toggle.addEventListener("click", (e) => {
      e.preventDefault();
      e.stopPropagation();
      openPanel(!panel.classList.contains("is-open"));
    });

    document.addEventListener("click", (e) => {
      if (!panel.classList.contains("is-open")) return;
      if (
        !panel.contains(e.target) &&
        e.target !== toggle &&
        !toggle.contains(e.target)
      ) {
        openPanel(false);
      }
    });

    document.addEventListener("keydown", (e) => {
      if (e.key === "Escape") openPanel(false);
    });

    
    let lastScrollY = window.scrollY;
    
    window.addEventListener("scroll", () => {
      placePanel();
      
      
      if (panel.classList.contains("is-open")) {
        console.log('Menu is open, closing due to scroll');
        openPanel(false);
      }
      
      lastScrollY = window.scrollY;
    }, { passive: true });

    window.addEventListener("resize", placePanel);
  }

  ready(async () => {
    const didHeader = await includePart(
      "#site-header",
      "Components/header.html",
    );
    const didFooter = await includePart(
      "#site-footer",
      "Components/footer.html",
    );
    await includePart("#cta-connect", "Components/cta-connect.html");

    bindMenu();

    let tries = 0,
      max = 10;
    const t = setInterval(() => {
      bindMenu();
      tries++;
      if (tries >= max || document.querySelector("#allpagesToggle"))
        clearInterval(t);
    }, 150);
  });
})();

document.addEventListener("DOMContentLoaded", function () {
  document.querySelectorAll(".faq-q").forEach((btn) => {
    if (btn.dataset.faqBound === "1") return;
    btn.dataset.faqBound = "1";

    const toggle = (e) => {
      if (e) e.preventDefault();
      const item = btn.closest(".faq-item");
      if (!item) return;
      const list = item.parentElement;
      const single = list?.dataset.accordion === "single";

      if (single && list) {
        list.querySelectorAll(".faq-item.is-open").forEach((i) => {
          if (i !== item) {
            i.classList.remove("is-open");
            const b = i.querySelector(".faq-q");
            b && b.setAttribute("aria-expanded", "false");
          }
        });
      }

      const nowOpen = !item.classList.contains("is-open");
      item.classList.toggle("is-open", nowOpen);
      btn.setAttribute("aria-expanded", String(nowOpen));
    };

    btn.addEventListener("click", toggle);
    btn.addEventListener("keydown", (e) => {
      if (e.key === "Enter" || e.key === " ") {
        e.preventDefault();
        toggle();
      }
    });
  });
});
